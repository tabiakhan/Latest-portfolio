/* =========================================================
   PORTFOLIO JAVASCRIPT
   Vanilla JavaScript only
========================================================= */


/* =========================================================
   PERSONAL DATA
   Replace the values below with your information.
========================================================= */

const portfolioData = {

    name: "Tabia Khan",

    email: "tabiazehra07@gmail.com",

    linkedin: "https://www.linkedin.com/in/tabia-khan",

    github: "https://github.com/tabiazehra"
};


/* =========================================================
   TYPING ANIMATION
========================================================= */

const typingText = document.getElementById("typingText");

const roles = [
    "Graphic Designer",
    "Front-End Developer",
    "Back-End Developer",
    "Web Developer",
    "Content Writer",
    "WordPress Publisher"
];

let roleIndex = 0;
let characterIndex = 0;
let deleting = false;
let typingTimer = null;


function typeRole() {

    if (!typingText || !roles.length) {
        return;
    }

    const currentRole = roles[roleIndex];

    if (!deleting) {

        typingText.textContent =
            currentRole.substring(
                0,
                characterIndex + 1
            );

        characterIndex++;

        if (characterIndex === currentRole.length) {

            deleting = true;

            typingTimer = setTimeout(typeRole, 1700);

            return;
        }

    } else {

        typingText.textContent =
            currentRole.substring(
                0,
                characterIndex - 1
            );

        characterIndex--;

        if (characterIndex === 0) {

            deleting = false;

            roleIndex =
                (roleIndex + 1) % roles.length;
        }
    }

    const speed = deleting ? 45 : 85;

    typingTimer = setTimeout(typeRole, speed);
}


if (typingText) {
    typingTimer = setTimeout(typeRole, 300);
}


/* =========================================================
   HEADER SCROLL
========================================================= */

const header =
    document.getElementById("header");

const backToTop =
    document.getElementById("backToTop");


function handleScroll() {

    if (!header || !backToTop) {
        return;
    }

    if (window.scrollY > 50) {

        header.classList.add("scrolled");

    } else {

        header.classList.remove("scrolled");
    }


    if (window.scrollY > 500) {

        backToTop.classList.add("show");

    } else {

        backToTop.classList.remove("show");
    }
}


window.addEventListener(
    "scroll",
    handleScroll
);


/* =========================================================
   MOBILE NAVIGATION
========================================================= */

const menuToggle =
    document.getElementById("menuToggle");

const navMenu =
    document.getElementById("navMenu");


if (menuToggle && navMenu) {

    menuToggle.addEventListener(
        "click",
        () => {

            const isOpen =
                navMenu.classList.toggle("open");

            menuToggle.setAttribute(
                "aria-expanded",
                isOpen
            );

            document.body.classList.toggle(
                "no-scroll",
                isOpen
            );

        }
    );


    document
        .querySelectorAll(".nav-link")
        .forEach(link => {

            link.addEventListener(
                "click",
                () => {

                    navMenu.classList.remove("open");

                    menuToggle.setAttribute(
                        "aria-expanded",
                        "false"
                    );

                    document.body.classList.remove(
                        "no-scroll"
                    );

                }
            );

        });
}


/* =========================================================
   ACTIVE NAVIGATION
========================================================= */

const sections =
    document.querySelectorAll("section[id]");

const navLinks =
    document.querySelectorAll(".nav-link");


function updateActiveNavigation() {

    const scrollPosition =
        window.scrollY + 150;


    sections.forEach(section => {

        const sectionTop =
            section.offsetTop;

        const sectionHeight =
            section.offsetHeight;

        const sectionId =
            section.getAttribute("id");


        if (
            scrollPosition >= sectionTop &&
            scrollPosition <
                sectionTop + sectionHeight
        ) {

            navLinks.forEach(link => {

                link.classList.remove("active");

            });


            const activeLink =
                document.querySelector(
                    `.nav-link[href="#${sectionId}"]`
                );


            if (activeLink) {

                activeLink.classList.add("active");

            }

        }

    });

}


window.addEventListener(
    "scroll",
    updateActiveNavigation
);


/* =========================================================
   SCROLL REVEAL
========================================================= */

const revealElements =
    document.querySelectorAll(".reveal");


const revealObserver =
    new IntersectionObserver(
        (entries, observer) => {

            entries.forEach(entry => {

                if (entry.isIntersecting) {

                    entry.target.classList.add(
                        "visible"
                    );

                    observer.unobserve(
                        entry.target
                    );
                }

            });

        },
        {
            threshold: 0.12
        }
    );


revealElements.forEach(element => {

    revealObserver.observe(element);

});


/* =========================================================
   PROJECT DATA
   Add/edit projects here.
========================================================= */

const projects = [

    {
        title: "Pharmacy Inventory System",
        category: "Full stack",
        categoryName: "Full Stack Project",

        description:
            "A Pharmacy Inventory System is a web-based application designed to help pharmacies manage their inventory efficiently. It allows users to track and manage the stock of medicines, monitor expiration dates, generate reports, and streamline the overall inventory management process. The system provides features such as adding new products, updating stock levels, and generating alerts for low stock or expired items. It aims to improve the accuracy and efficiency of inventory management in pharmacies.",

        image:
            "assets/images/project-pharmacy.jpg",

        technologies: [
            "HTML",
            "CSS",
            "JavaScript",
            "Database",
            "Node.js"
        ],

        live:
            "https://www.linkedin.com/feed/update/urn:li:activity:7428113322241048576/",

        github:
            "https://github.com/tabiakhan/pharmacy-inventory-system"
    },


    {
        title: "Rock Paper Scissors Java Game",
        category: "web",
        categoryName: "Java Project",

        description:
            "Rock Paper Scissors is an interactive desktop-based game developed using Java Swing. It allows users to play the classic Rock Paper Scissors game against the computer through a simple and user-friendly graphical interface. The system generates random choices for the computer, compares them with the user's selection, and displays the game result. It also keeps track of scores and provides immediate feedback after each round. The project demonstrates the use of Java programming, Swing components, event handling, conditional logic, and randomization to create an engaging interactive application.",

        image:
            "assets/images/project-rps.jpg",

        technologies: [
            "Java",
            "Swing"
        ],

        

        github:
            "https://github.com/tabiakhan/ROCK-PAPER-AND-SCISSOR-GAME"
    },


    {
        title: "Library Management System",
        category: "Full Stack",
        categoryName: "Full Stack Project",

        description:
            "A Library Management System is a full-stack web-based application designed to help libraries manage their books, students, and daily operations efficiently. It allows users to add and manage books, track availability, record borrowing and returning activities, and maintain organized library records. The system provides features such as book management, student records, issue and return tracking, and database management. Developed using Python, HTML, CSS, JavaScript, and a database, the project aims to improve the accuracy, organization, and efficiency of library management.",

        image:
            "assets/images/project-library.jpg",

        technologies: [
            "HTML",
            "CSS",
            "JavaScript",
            "Database",
            "Python"
        ],

        live:
            "https://www.linkedin.com/feed/update/urn:li:activity:7428107057225945088/?originTrackingId=tSef5EyGTuem9ldX5AoVUQ%3D%3D",

        github:
            "https://github.com/tabiakhan/Library-Management-System"
    },


    {
        title: "Ecommerce Website",
        category: "Full Stack",
        categoryName: "Full Stack Project",

        description:
            "A modern full-stack e-commerce website designed for a fashion and lifestyle store offering sunglasses, clothing, accessories, and other products. The website provides customers with an easy-to-use shopping experience through organized product categories, detailed product pages, user accounts, shopping cart functionality, and a streamlined checkout process. The project focuses on creating a visually appealing, responsive, and user-friendly online shopping platform."
,

        image:
            "assets/images/project-watch.jpg",

        technologies: [
            "HTML",
            "CSS",
            "JavaScript",
            "UI/UX"
        ],

        live :
            "https://www.linkedin.com/feed/update/urn:li:activity:7428104104134033408/?originTrackingId=CcrFj5hHTvS9i%2F7WFpRqsQ%3D%3D",

        github:
            "https://github.com/tabiakhan/Ecommerce-wesbite"
    },


    {
        title: "Intellegent Traffic Navigation System ",
        category: "AI & Software Development",
        categoryName: "AI & Software Development",

        description:
            "An Intelligent Traffic Navigation System is a Python-based project designed to assist users in finding efficient routes based on traffic conditions and available navigation options. The system focuses on analyzing routes and making intelligent decisions to help users select suitable paths for smoother and more efficient travel. It demonstrates the practical use of Python programming, navigation logic, problem-solving, and intelligent decision-making. The project aims to provide a simple and effective approach to route planning while considering traffic-related conditions."
,
        image:
            "assets/images/project-traffic.jpg",

        technologies: [
            "Python",
            "AI",
            "Software Development"
        ],

        live:
            "https://www.linkedin.com/feed/update/urn:li:activity:7467240988684566530/",

        github:
            "https://github.com/tabiakhan/Intellegent-Traffic-Navigation-System"
    },


    {
        title: "Sales Management System",
        category: "Full Stack",
        categoryName: "Full Stack Project",

        description:
            "A full-stack Sales Management System designed with two major portals: Manager and Customer. The Manager portal provides tools to manage products, inventory, sales, orders, and customer records, while the Customer portal allows users to browse available products, view product details, place orders, and manage their purchases. The project focuses on creating an organized and efficient sales platform with a user-friendly interface and separate functionalities based on user roles."
,

        image:
            "assets/images/project-marketing.jpg",

        technologies: [
            "HTML",
            "CSS",
            "JavaScript",
            "Node.js",
            "Database"
        ],

        live:
            "https://www.linkedin.com/feed/update/urn:li:activity:7428114284305383425/",

        github:
            "https://github.com/tabiakhan/Sales-Management-System"
    },


    {
        title: "AI/ML data analysis project",
        category: "ai",
        categoryName: "AI & Software Development",

        description:
            "A data analysis and AI/ML project focused on analyzing a mental hospital dataset to discover meaningful patterns and insights. The project involves data cleaning, handling missing and inconsistent values, preprocessing, exploratory data analysis (EDA), and data visualization. Various aspects of the dataset are analyzed to understand trends, relationships, and important factors within the collected data. This project demonstrates practical skills in data preprocessing, EDA, visualization, analytical thinking, and preparing real-world datasets for AI/ML applications."
            ,

        image:
            "assets/images/design-collection.jpg",

        technologies: [
            "Python",
            "Machine Learning"
        ],

        live:
            "https://www.linkedin.com/feed/update/urn:li:activity:7428114284305383425/",

        github:
            "https://github.com/tabiakhan/AI-ML-data-analysis-project-"
    },


    
        ,


    {
        title: "WordPress Website",
        category: "wordpress",
        categoryName: "WordPress",

        description:
            "As a WordPress Publisher, I have experience managing and publishing website content for digital marketing projects. My work includes uploading and formatting articles, editing AI-generated content, adding and optimizing images, creating service pages and product descriptions, organizing website content, and maintaining clean and consistent page layouts.I also have experience with SEO-focused content publishing and tools such as NeuronWriter. I focus on presenting content in a clear, engaging, and well-structured format while maintaining website consistency and improving overall content quality. This role has helped me develop practical skills in WordPress management, content editing, SEO, website organization, and digital publishing."
,

        image:
            "assets/images/project-wordpress.jpg",

        technologies: [
            "WordPress"
        ],

        live:
            "https://www.linkedin.com/feed/update/urn:li:activity:7504985415897010176/",

      
    },


    {
        title: "Content Writing Samples",
        category: "content",
        categoryName: "Content",

        description:
            "Experienced in creating and optimizing engaging, informative, and SEO-friendly content for websites and digital marketing projects. My work includes blog posts, service pages, website content, product descriptions, and other online content.I use NeuronWriter to research keywords, analyze content, improve topical coverage, and optimize articles for search engines while keeping the writing natural and reader-focused. I also work with AI-assisted drafts, editing and refining them through research, proofreading, optimization, and human-focused improvements.",

        image:
            "assets/images/content-writing.jpg",

        technologies: [
            "Content Writing",
            "WordPress"
        ],

        live:
            "https://www.linkedin.com/feed/update/urn:li:activity:7504987478081036288/",

       
    }

];


/* =========================================================
   PROJECT RENDERING
========================================================= */

const projectsGrid =
    document.getElementById(
        "projectsGrid"
    );


function createProjectCard(project) {

    const card =
        document.createElement("article");

    card.className =
        "project-card reveal visible";


    const imageHTML =
        project.image
            ? `
                <img
                    src="${project.image}"
                    alt="${project.title}"
                    loading="lazy"
                    onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                >

                <div
                    class="project-placeholder"
                    style="display:none;"
                >
                    <span>◈</span>
                    
                </div>
            `
            : `
                <div class="project-placeholder">
                    <span>◈</span>
                    
                </div>
            `;


    const techHTML =
        project.technologies
            .map(
                tech =>
                    `<span>${tech}</span>`
            )
            .join("");


    const githubHTML =
        project.github &&
        !project.github.startsWith("[")
            ? `
                <a
                    href="${project.github}"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    GitHub
                </a>
              `
            : `
                <a
                    href="#"
                    onclick="return false;"
                    title="Add GitHub URL"
                >
                    GitHub
                </a>
              `;


    const liveHTML =
        project.live &&
        !project.live.startsWith("[")
            ? `
                <a
                    href="${project.live}"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    Live Demo
                </a>
              `
            : `
                <a
                    href="#"
                    onclick="return false;"
                    title="Add Live Demo URL"
                >
                    Live Demo
                </a>
              `;


    card.innerHTML = `

        <div class="project-image">

            ${imageHTML}

        </div>


        <div class="project-body">

            <span class="project-category">
                ${project.categoryName}
            </span>

            <h3>
                ${project.title}
            </h3>

            <p>
                ${project.description}
            </p>

            <div class="project-tech">
                ${techHTML}
            </div>

            <div class="project-links">

                ${liveHTML}

                ${githubHTML}

            </div>

        </div>

    `;


    return card;
}


function renderProjects(filter = "all") {

    projectsGrid.innerHTML = "";


    const filteredProjects =
        filter === "all"
            ? projects
            : projects.filter(
                project =>
                    project.category === filter
            );


    filteredProjects.forEach(project => {

        const card =
            createProjectCard(project);

        projectsGrid.appendChild(card);

    });

}


renderProjects();


/* =========================================================
   PROJECT FILTERS
========================================================= */

const filterButtons =
    document.querySelectorAll(
        ".filter-btn"
    );


filterButtons.forEach(button => {

    button.addEventListener(
        "click",
        () => {

            filterButtons.forEach(btn => {

                btn.classList.remove("active");

            });


            button.classList.add("active");


            const filter =
                button.dataset.filter;


            renderProjects(filter);

        }
    );

});


/* =========================================================
   GRAPHIC DESIGN DATA
========================================================= */

const designs = [

    {
        title: "Social Media Design",
        category: "social",
        image: "assets/images/Screenshot 2026-09-08 212536.png"
    },

    {
        title: "Banner Design",
        category: "banner",
        image: "assets/images/design-2.jpg"
    },

    {
        title: "Poster Design",
        category: "poster",
        image: "assets/images/design-3.jpg"
    },

    {
        title: "Menu Design",
        category: "menu",
        image: "assets/images/design-4.jpg"
    },

    {
        title: "UI/UX Design",
        category: "uiux",
        image: "assets/images/design-5.jpg"
    },

    {
        title: "Social Media Graphic",
        category: "social",
        image: "assets/images/design-6.jpg"
    },

    {
        title: "Marketing Banner",
        category: "banner",
        image: "assets/images/design-7.jpg"
    },

    {
        title: "Creative Poster",
        category: "poster",
        image: "assets/images/design-8.jpg"
    }

];


/* =========================================================
   DESIGN GALLERY
========================================================= */

const designGallery =
    document.getElementById(
        "designGallery"
    );


function renderDesigns(filter = "all") {

    if (!designGallery) {
        return;
    }

    designGallery.innerHTML = "";


    const filtered =
        filter === "all"
            ? designs
            : designs.filter(
                design =>
                    design.category === filter
            );


    filtered.forEach(design => {

        const item =
            document.createElement("div");

        item.className =
            "design-item";


        item.innerHTML = `

            <img
                src="${design.image}"
                alt="${design.title}"
                loading="lazy"
                onerror="
                    this.style.display='none';
                    this.parentElement.classList.add('missing-design');
                "
            >

            <div class="design-overlay">

                <div>

                    <h3>
                        ${design.title}
                    </h3>

                    <p>
                        Click to enlarge
                    </p>

                </div>

            </div>

        `;


        item.addEventListener(
            "click",
            () => {

                openLightbox(
                    design.image,
                    design.title
                );

            }
        );


        designGallery.appendChild(item);

    });

}


renderDesigns();


/* =========================================================
   DESIGN FILTERS
========================================================= */

const designFilterButtons =
    document.querySelectorAll(
        ".design-filter"
    );


designFilterButtons.forEach(button => {

    button.addEventListener(
        "click",
        () => {

            designFilterButtons.forEach(btn => {

                btn.classList.remove(
                    "active"
                );

            });


            button.classList.add(
                "active"
            );


            renderDesigns(
                button.dataset.designFilter
            );

        }
    );

});


/* =========================================================
   LIGHTBOX
========================================================= */

const lightbox =
    document.getElementById(
        "lightbox"
    );

const lightboxImage =
    document.getElementById(
        "lightboxImage"
    );

const lightboxClose =
    document.getElementById(
        "lightboxClose"
    );


function openLightbox(
    image,
    title
) {

    if (!lightbox || !lightboxImage) {
        return;
    }

    lightboxImage.src = image;

    lightboxImage.alt = title;

    lightbox.classList.add("open");

    lightbox.setAttribute(
        "aria-hidden",
        "false"
    );

    document.body.classList.add(
        "no-scroll"
    );

}


function closeLightbox() {

    if (!lightbox) {
        return;
    }

    lightbox.classList.remove(
        "open"
    );

    lightbox.setAttribute(
        "aria-hidden",
        "true"
    );

    document.body.classList.remove(
        "no-scroll"
    );

}


if (lightboxClose) {
    lightboxClose.addEventListener(
        "click",
        closeLightbox
    );
}


if (lightbox) {
    lightbox.addEventListener(
        "click",
        event => {

            if (
                event.target === lightbox
            ) {

                closeLightbox();

            }

        }
    );
}


document.addEventListener(
    "keydown",
    event => {

        if (event.key === "Escape") {

            closeLightbox();

        }

    }
);


/* =========================================================
   CERTIFICATION DATA
========================================================= */

const certifications = [

    {
        title: "[CERTIFICATION NAME]",
        platform: "[PLATFORM / INSTITUTE]",
        date: "[COMPLETION DATE]",
        link: "[ADD CERTIFICATE LINK]"
    },

    {
        title: "[CERTIFICATION NAME]",
        platform: "[PLATFORM / INSTITUTE]",
        date: "[COMPLETION DATE]",
        link: "[ADD CERTIFICATE LINK]"
    },

    {
        title: "[CERTIFICATION NAME]",
        platform: "[PLATFORM / INSTITUTE]",
        date: "[COMPLETION DATE]",
        link: "[ADD CERTIFICATE LINK]"
    }

];


/* =========================================================
   CERTIFICATION RENDERING
========================================================= */

const certificationGrid =
    document.getElementById(
        "certificationGrid"
    );


function renderCertifications() {

    if (!certificationGrid) {
        return;
    }

    certificationGrid.innerHTML = "";


    certifications.forEach(
        certificate => {

            const card =
                document.createElement(
                    "article"
                );


            card.className =
                "certification-card reveal visible";


            const validLink =
                certificate.link &&
                !certificate.link.startsWith(
                    "["
                );


            card.innerHTML = `

                <div class="certification-icon">
                    ✦
                </div>

                <h3>
                    ${certificate.title}
                </h3>

                <p>
                    ${certificate.platform}
                </p>

                <p>
                    ${certificate.date}
                </p>

                ${
                    validLink
                        ? `
                            <a
                                href="${certificate.link}"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                View Certificate →
                            </a>
                          `
                        : `
                            <span
                                style="
                                    color:var(--text-muted);
                                    font-size:.75rem;
                                "
                            >
                                [ADD CERTIFICATE LINK]
                            </span>
                          `
                }

            `;


            certificationGrid.appendChild(
                card
            );

        }
    );

}


renderCertifications();


/* =========================================================
   CONTACT FORM
========================================================= */

const contactForm =
    document.getElementById(
        "contactForm"
    );

const formStatus =
    document.getElementById(
        "formStatus"
    );


if (contactForm && formStatus) {

    contactForm.addEventListener(
        "submit",
        event => {

            event.preventDefault();


            const name =
                document.getElementById(
                    "name"
                ).value.trim();


            const email =
                document.getElementById(
                    "email"
                ).value.trim();


            const subject =
                document.getElementById(
                    "subject"
                ).value.trim();


            const message =
                document.getElementById(
                    "message"
                ).value.trim();


            if (
                !name ||
                !email ||
                !subject ||
                !message
            ) {

                formStatus.textContent =
                    "Please complete all fields.";

                return;
            }


            const emailAddress =
                portfolioData.email;


            if (
                !emailAddress ||
                emailAddress.includes("[")
            ) {

                formStatus.textContent =
                    "Please add your email address in script.js first.";

                return;
            }


            const body =

                `Hello ${portfolioData.name},\n\n` +

                `Name: ${name}\n` +

                `Email: ${email}\n\n` +

                `${message}`;


            const mailto =

                `mailto:${emailAddress}` +

                `?subject=${encodeURIComponent(
                    subject
                )}` +

                `&body=${encodeURIComponent(
                    body
                )}`;


            window.location.href =
                mailto;


            formStatus.textContent =
                "Opening your email application...";

        }
    );
}


/* =========================================================
   BACK TO TOP
========================================================= */

if (backToTop) {
    backToTop.addEventListener(
        "click",
        () => {

            window.scrollTo({

                top: 0,

                behavior: "smooth"

            });

        }
    );
}


/* =========================================================
   DARK / LIGHT MODE
========================================================= */

const themeToggle =
    document.getElementById(
        "themeToggle"
    );


if (themeToggle) {
    const savedTheme =
        localStorage.getItem(
            "portfolio-theme"
        );


    if (
        savedTheme === "light"
    ) {

        document.body.classList.add(
            "light-mode"
        );

        themeToggle.textContent = "☾";

    }


    themeToggle.addEventListener(
        "click",
        () => {

            document.body.classList.toggle(
                "light-mode"
            );


            const lightMode =
                document.body.classList.contains(
                    "light-mode"
                );


            themeToggle.textContent =
                lightMode
                    ? "☾"
                    : "☼";


            localStorage.setItem(
                "portfolio-theme",
                lightMode
                    ? "light"
                    : "dark"
            );

        }
    );
}


/* =========================================================
   CURRENT YEAR
========================================================= */

const currentYear =
    document.getElementById(
        "currentYear"
    );

if (currentYear) {
    currentYear.textContent =
        new Date().getFullYear();
}


/* =========================================================
   IMAGE ERROR HANDLING
========================================================= */

document.addEventListener(
    "error",
    event => {

        if (
            event.target.tagName === "IMG"
        ) {

            event.target.style.opacity =
                "0.25";

        }

    },
    true
);
/* =========================
GRAPHIC DESIGN REVEAL
========================= */

document.addEventListener("DOMContentLoaded", () => {

const revealElements = document.querySelectorAll(".reveal");

const revealObserver = new IntersectionObserver(
    (entries, observer) => {

        entries.forEach((entry) => {

            if (entry.isIntersecting) {

                entry.target.classList.add("active");

                observer.unobserve(entry.target);
            }

        });

    },
    {
        threshold: 0.12
    }
);

revealElements.forEach((element) => {
    revealObserver.observe(element);
});


/* =========================
   IMAGE HOVER EFFECT
========================= */

const designCards = document.querySelectorAll(".design-card");

designCards.forEach((card) => {

    const image = card.querySelector("img");

    if (!image) return;

    card.setAttribute("role", "button");
    card.setAttribute("tabindex", "0");

    const openDesign = () => {
        openLightbox(image.src, image.alt);
    };

    card.addEventListener("click", openDesign);

    card.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            openDesign();
        }
    });

    card.addEventListener("mousemove", (event) => {

        const rect = card.getBoundingClientRect();

        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;

        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = ((y - centerY) / centerY) * -2;
        const rotateY = ((x - centerX) / centerX) * 2;

        card.style.transform =
            `translateY(-8px) perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;

    });


    card.addEventListener("mouseleave", () => {

        card.style.transform =
            "translateY(0) perspective(800px) rotateX(0) rotateY(0)";

    });

});

});
